/**
 * Programmer: 	Sharma Chakravarthy, Soumyava Das
 * Language:	Java
 * date:        09/10/2012
 * Purpose:		This program uses MavBoyTest class to read data from a text file to initialize
 * 				employees, items, clients, etc.
 * 				
 *              It checks and recovers from some exceptions while reading the input file
 *                 uses a bufferedReader which is different from project 2
 *              NO assumptions on the #employees etc. adjust your code accordingly!
 
 *              also shows how to write to an output file
 * 
 * USAGE:       You need to initialize your data structures as the first step. 
 *              once the values are read into local variables, 
 *              it  is YOUR responsibility to add code at proper places to create objects and manage them!
 *
 *              input and output file names are given as a command line argument 
 *              (e.g, java MavBoyTest dataFile-proj3.txt proj3-output.txt)
 *              for the naming convention used in this file. if you forget to give the data 
 *              files as  command line arguments, it will prompt you for that.	
 *          
 *              you can remove or comment out prints once you are sure it is reading the input correctly
 *
 * MAKE SURE:   your program is case insensitive (for state code, city, gender, employee type etc.)
 */

import java.io.*;
import java.util.*;
import java.util.Scanner;

/**
 * @param inputfileName
 *            as input data filename contaning input items with : as item separators
 * @param   outputFileName as output file name 
 */

public class MavBoyTest implements DateConstants, Proj3Constants {

	// introduce your (class and instance) attributes for this test class

	private static BufferedReader finput;
    private static Scanner cp;  //this is still command prompt
    private static PrintWriter foutput;

    //define other variables as needed

	//Note that we are using a DIFFERENT method for reading input file;
	/**
	 * @param iFileName is the input data file name
	 */		

    public static BufferedReader openReadFile(String fileName){
        BufferedReader bf = null;
        try{
            bf = new BufferedReader(new FileReader(fileName));
        }     
        catch(FileNotFoundException FNFE){    
          bf = null;
        }
       finally{
          return bf;
       }
    }

/**
	 * @param oFileName is the input data file name
	 */		

    
    public static PrintWriter openWriteFile(String fileName){
        PrintWriter outputFile = null;
        try{
            outputFile = new PrintWriter(new FileWriter(fileName));
        }     
        catch(IOException IOE){    
          outputFile = null;
        }
       finally{
          return outputFile;
       }
    }

	// add here constructors and methods as needed

	/**
	 * @param takes
	 *            fileNames as command line argument. prompts if not given
	 */
	public static void main(String[] args) {

		// declare variables used for input handling
        String enterprisename = DEFAULT_ENTERPRISE_NAME;
        String inputLine = "", ifName = "", ofName = "";

		// determine if correct input file is provided

		cp = new Scanner(System.in);
		if (args.length < 1) {
			System.out.println("Input Data file name was not supplied");
			System.out.printf("Please type input data file name: ");
			ifName = "dataFile-proj3-new.txt";//cp.nextLine();\
            ofName = "out.txt";//cp.nextLine();
		} 
        else if (args.length < 2){
            ifName =  args[ZEROI];       
            System.out.printf("Please type output data file name: ");
            //ofName = "C:\\Users\\Keenan\\Desktop\\UTA\\Fall 2015\\Object Orientied programming (JAVA)\\proj3_Keenan_Parker_final_001\\out.txt";//cp.nextLine();
        } else {
            ifName = args[ZEROI];
            ofName = args[ONEI];
            }

		// See HOW RECOVERY is done (will cover in a few weeks)
		System.out.println("ifName ="+ifName);
		System.out.println("ofName ="+ofName);
		finput = openReadFile(ifName);
		while (finput == null) {
			System.out.println("ifName ="+ifName);
			System.out.println("Error: Input FILE "+ ifName+" does not exist.\nEnter correct file name: ");
			ifName = cp.nextLine();
			finput = openReadFile(ifName);
		}
        foutput = openWriteFile(ofName);
		System.out.println("ofName ="+ofName);
        while (foutput == null){
			System.out.printf("Error: Output FILE %s %s",  ofName,  " does not exist.\nEnter correct file name: ");
            ofName = cp.nextLine();
            foutput = openWriteFile(ofName);
		}  

		/* GET SportsMgmt DETAILS */
		// start reading from data file
		// get name
		try {
			inputLine = finput.readLine();
			while (inputLine.charAt(BASE_INDEX) == '/')
				inputLine = finput.readLine();
			String enterpriseName = inputLine;
			System.out.printf("\n%s %s \n", "Enterprise name is: ",
					enterpriseName);

			// add code as needed
                        Enterprise mavBoy = new Enterprise(enterpriseName);
			/* GET numbers of empoyees, donors, athletes, and number of donations
			inputLine = finput.readLine();
			while (inputLine.charAt(BASE_INDEX) == '/')
				inputLine = finput.readLine();

			// reading 4 values from a single line
			String[] chopInputLine = inputLine.split(":");

			int numEmployees = Integer.parseInt(chopInputLine[ZEROI]);
			int numDonors = Integer.parseInt(chopInputLine[ONEI]);
			int numAthletes = Integer.parseInt(chopInputLine[TWOI]);
			int numDonations = Integer.parseInt(chopInputLine[THREEI]);

			System.out.printf("\nnumEmp, numDonors, numAthletes, numDonations: [%5d, %5d, %5d, %5d]\n",
							numEmployees, numDonors, numAthletes, numDonations);

			// add code here: use the above to initialize your arrays, arraylists,
			// and attributes as needed
            */

			/* GET EMPLOYEE DETAILS */

			// reading details for each employee from the data file
			System.out.printf("\nEmployees: \n");
	        int numEmployees = 0;
            inputLine = finput.readLine();
			while (inputLine.charAt(BASE_INDEX) == '/')
					inputLine = finput.readLine();		
			while ( (!inputLine.toLowerCase().equals("end"))){
            	
				String[] chopEmp = inputLine.split(":");

				// fill all fields for a single employee from a single line
				String empType = chopEmp[ZEROI];
				String empFName = chopEmp[ONEI];
			    String empLName = chopEmp[TWOI];
				String empBDate = chopEmp[THREEI];
				String empGender = chopEmp[FOURI];
				String empHireDate = chopEmp[FIVEI];
                double empBaseSalary = Double.parseDouble(chopEmp[SIXI]);
                double empRate = Double.parseDouble(chopEmp[SEVENI]);
                
				// add code here: in order to convert a date string to a Date object,
				// use the following
				// i.e., invoke the appropriate constructor of the Date class
				Date dob = new Date(empBDate);
                                //Player(String first, String last, String gen, String dob, String joinDate, double salary,double bonus)
                                //Support(String first, String last, String gen, String dob, String joinDate, double salary,double overtimeRate)
                                //Sales(String first, String last, String gen, String dob, String joinDate,double payRate)
                                mavBoy.hireEmployee(empFName, empLName, empGender, empBDate, empType, empHireDate, empBaseSalary,empRate);
				System.out.printf("(%6s, %10s, %6s, %12s, %10.2f, %4s, %12s, %.2f)\n",
						empFName, empLName, empGender, empHireDate,
						empBaseSalary, empType, dob, empRate);

				// add code here: also, empTYpe is read as a string; if u are using a
				// enum, you need to convert it  using a switch or if statement

                //add this employee to array list
                inputLine = finput.readLine();
				while (inputLine.charAt(BASE_INDEX) == '/')
					inputLine = finput.readLine();	
                numEmployees +=1;
			}
            System.out.printf("#Employees: %d\n", numEmployees);

			// reading details of items from the data file
			System.out.printf("\nItems: \n");

            int numItems =0;
			inputLine = finput.readLine();
			while (inputLine.charAt(BASE_INDEX) == '/')
					inputLine = finput.readLine();

            while ( (!inputLine.toLowerCase().equals("end"))){
				String[] chopitem = inputLine.split(":");

				// get all fields of the donor
				String itemId = chopitem[ZEROI];
                String itemName = chopitem[ONEI];
                String itemDepartment = chopitem[TWOI];
				double itemPrice = Double.parseDouble(chopitem[THREEI]);
                String itemSize= chopitem[FOURI];
				String itemType = chopitem[FIVEI];
                int itemQuantity = Integer.parseInt(chopitem[SIXI]);
				
                   mavBoy.addItem(itemId,itemName,itemDepartment, itemPrice, itemSize, itemType,itemQuantity);//Added by keenan
				System.out.printf("[%s, %s, %s, %f, %s, %s, %d]\n", 
                    itemId, itemName, itemDepartment, itemPrice, 
                               itemSize, itemType, itemQuantity);

				// add code here to add item object to the enterprise

                inputLine = finput.readLine();
				while (inputLine.charAt(BASE_INDEX) == '/')
					inputLine = finput.readLine();	
                numItems +=1;
			}
            System.out.printf("#Items: %d\n", numItems);

			/* GET CLIENT DETAILS */

			// reading details for each client from the data file
			System.out.printf("\nClients: \n");
			
            int numClients =0;
			inputLine = finput.readLine();
			while (inputLine.charAt(BASE_INDEX) == '/')
				inputLine = finput.readLine();

            while ( (!inputLine.toLowerCase().equals("end"))){
				String[] chopAthlete = inputLine.split(":");

				// fill all fields for a single client from a single line
				String[] chopClient = inputLine.split(":");
									
				// fill all fields for a single client from a single line 
				int clientId = Integer.parseInt(chopClient[ZEROI]);
				String clientFName = chopClient[ONEI];
                String clientLName = chopClient[TWOI];
				String clientDOB = chopClient[THREEI];
				String clientGender = chopClient[FOURI];
				String clientMemType = chopClient[FIVEI];
				String clientSince = chopClient[SIXI];	
				int  clientHouseNum = Integer.parseInt(chopClient[SEVENI]);
                String clientStreet = chopClient[EIGHTI];
                String clientCity = chopClient[NINEI];
                String clientState = chopClient[TENI];
                
				// add code: construct client object as appropriate
			    String customerHouseNum = Integer.toString(clientHouseNum);
                            mavBoy.addCustomer((int)clientId, clientFName, clientLName, clientGender, clientDOB, clientMemType, clientSince, customerHouseNum, clientStreet, clientCity, clientState);//Added code by Keenan
				System.out.printf("{%d, %s, %s, %s, %s, %s, %s, %d, %s, %s, %s} \n",
                    clientId, clientFName, clientLName, clientDOB, clientGender, clientMemType, clientSince,  
				    clientHouseNum, clientStreet, clientCity, clientState);


                inputLine = finput.readLine();
				while (inputLine.charAt(BASE_INDEX) == '/')
					inputLine = finput.readLine();
                numClients += 1;
			}
            System.out.printf("#clients: %d\n", numClients);
            
			// process menu from here
			/*
            Scanner mavInputString = new Scanner(System.in);
            Scanner mavInputInt = new Scanner(System.in);
            Scanner mavMainInput = new Scanner(System.in);
            String userInput = "";
            String buyDate;
            String state,stateUpper;
            int empId;
            int customerId;
            String itemId;
            int qunaity;
            while (!"0".equals(userInput))
            {
                System.out.println("10) Show the menu of project 2 (we will not test this! This will allow you to keep the code of project 2 rather than removing it)");
                System.out.println("11) Process items bought by a client (same as project 2, but from a file) Input: client id, item id, date (or * for today’s date), quantity");
                System.out.println("12) List items bought by a client (same as project 2, but from a file)");
                System.out.println("13) Hire a new employee Input: employee type, fname, lname, dob, gender, hire date, base salary double value");
                System.out.println("14) Release an employee (same as in project 2, but from input file) Input: employee id");
                System.out.println("15) Compute monthly salary of an employee Input: empid, (int) # of over-time hours for Support or number of hours for Sales or total games played by Player");
                System.out.println("16) expenditure Input: item id");
                System.out.println("17) Compute whether a client retains her gold status for the next year input: client id or *, year or *");
                System.out.println("0) Exit program");
                System.out.printf("Please enter your response: ");
                userInput = mavMainInput.nextLine();
                if("10".equals(userInput) || "11".equals(userInput)|| "12".equals(userInput) || "13".equals(userInput) || "14".equals(userInput)|| "15".equals(userInput)|| "16".equals(userInput)|| "17".equals(userInput)) 
                {
                    
                }
            }
            */
            while ((inputLine = finput.readLine()) != null){
            if (inputLine.charAt(BASE_INDEX) == '/'){
                System.out.println(inputLine);
                foutput.println(inputLine);
            }
            else {
            String[] chopInput = inputLine.split(":");
			int functionNum = (int) Integer.parseInt(chopInput[ZEROI]);
             //add code: for processing them; use a switch statement after converting the first field
             //you can use foutput.print or foutput.println statements to write to an output file 
             switch(functionNum)
             {
             	case 11:
             		int cID = Integer.parseInt(chopInput[ONEI]);
             		String iID = chopInput[TWOI];
             		String d = chopInput[THREEI];
             		int quan = Integer.parseInt(chopInput[FOURI]);
             		if("*".equals(d))
             		{
             			mavBoy.sellItem(iID,cID,quan);
             		}
             		else
             		{
             			mavBoy.sellItem(iID,cID,quan,d);
             		}
             		foutput.println("11");
             		break;
             	
             	case 12:
             		cID = Integer.parseInt(chopInput[ONEI]);
             		String y = chopInput[TWOI];
             		if("*".equals(y))
             		{
             			mavBoy.printCustomerPortfolio(cID);
             		}
             		else
             		{
             			mavBoy.printYearlyCustomerPortfolio(cID,y);
             		}
             		foutput.println("12");
             		break;
             		
             	case 13: 
             		//Input: employee type, fname, lname, dob, gender, hire date, base salary,double value
             		String eType = chopInput[ONEI];
             		String f = chopInput[TWOI];
             		String l = chopInput[THREEI];
             		String db =  chopInput[FOURI];
             		String g =  chopInput[FIVEI];
             		String dh =  chopInput[SIXI];
             		double salary = Double.parseDouble(chopInput[SEVENI]);
             		double rate = Double.parseDouble(chopInput[EIGHTI]);
             		mavBoy.hireEmployee(eType,f,l,db,g,dh,salary,rate);
             		foutput.println("13");
             		break;
             		
             	case 14:
             		int employeeID = Integer.parseInt(chopInput[ONEI]);
             		mavBoy.releaseEmployee(employeeID);
             		break;
             		
             	case 15: 
             		foutput.println("15");
             		break;
             		
             	case 16:
             		 iID = chopInput[ONEI];
             		mavBoy.itemPurchases(iID);
             		foutput.println("16");
             		break;
             	
             	case 17:
             		String cusID = chopInput[ONEI];
             		y = chopInput[TWOI];
             		mavBoy.retainCustomerType(y,cusID);
             		foutput.println("17");
             		break;
             	
             	case 0:
             		foutput.close();
             		System.exit(1);
					break;
             	
             }
             System.out.println(inputLine);
             foutput.println(inputLine);
          }	      
        }
			
		} catch (NumberFormatException NFE) {
			System.out.println("I/O Error in File: " + ifName + "\ncheck for: "
					+ NFE.getMessage() + " and correct it in: " + inputLine);
		} catch (RuntimeException RE) {
			System.out.println("Invalid Data error in File: " + ifName
					+ "\nPlease correct " + RE.getMessage() + " in the file!" + inputLine);
		}
        catch(IOException IOE){
        System.out.println("input/output Data error in File: " + ifName + "\nPlease correct " + IOE.getMessage() + " in the file!" + inputLine);
        }
        finally {
		  foutput.close();
		}
	}
}

//C:\Users\Keenan\Desktop\UTA\Fall 2015\Object Orientied programming (JAVA)\proj3_Keenan_Parker_final_001\dataFile-proj3-new.txt
