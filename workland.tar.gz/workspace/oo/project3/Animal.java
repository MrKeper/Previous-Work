/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Soumyava
 */
public class Animal
{
    public static void testClassMethod()
    { 
        System.out.println("The class method in Animal.");
    }
    
    public void testInstanceMethod()
    { 
        System.out.println("The instance method in Animal."); 
    }
    
    public static void main(String[] args)
    {
        
    }
}

class Cat extends Animal 
{ 
	public static void testClassMethod()
	{
            System.out.println("The class method in Cat.");
        }//hides superclass method
	public void testInstanceMethod()
	{
            System.out.println("The instance method in Cat.");
        } //  overrides superclass method
        public static void main(String[] args)
        { 
	Cat myCat = new Cat(); 
    Animal myAnimal = myCat; //this is fine!
        
	System.out.println("Output of line 1");
    Animal.testClassMethod(); //calling using class name
	System.out.println("Output of line 2");
    myCat.testClassMethod();		// what method is invoked?
	System.out.println("Output of line 3");
    Cat.testClassMethod();
    System.out.println("Output of line 4");
    myAnimal.testClassMethod();
    System.out.println("Output of line 5");
	myAnimal.testInstanceMethod(); //myAnimal has a Cat object
	System.out.println("Output of line 6");
    myCat.testInstanceMethod();
	//Cat.testInstanceMethod();  
    //myAnimal.testInstanceMethod();
    }
}