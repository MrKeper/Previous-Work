#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "hw6.h"

const int N_MAX = 100;

const Item STOP = 0;
tree_link tree_from_array_preorder_aux(Item arr[], int *pos, int N);
tree_link buildNode(Item i);

struct tree_struct
{
	tree_link root;	
};

struct tree_node_struct  //tree_link
{
   int item; 
   tree_link left;  
   tree_link right;
};


/* Creates a new link, that contains the value specified in the argument, 
 * and that points to NULL for both children. */
tree_link new_tree_link(Item value)
{  
   tree_link result = (tree_link)malloc(sizeof(struct tree_node_struct));
   result->item = value;
   result->left = NULL;
   result->right = NULL;
   return result;
}



void print_line(tree_link node, int depth)
{	
	int i;
	for (i = 0; i<depth; i++) printf("  ");
	
	if (node == NULL)
		printf("*\n");
	else
	{		
		printf("%d\n", node->item);	
	}
}

void print_tree(tree_link root, int depth, int order)
{
	if (root==NULL)
	{	
		print_line(root, depth);
		return;
	}
	
	if (order == 1)
	{		
		print_line(root, depth);
		print_tree(root->left, depth + 1, order);
		print_tree(root->right, depth + 1, order);
	}
	else
		if (order ==2)
		{			
			print_tree(root->right, depth + 1, order);		
			print_line(root, depth);
			print_tree(root->left, depth + 1, order);
		}
		else
			printf("Invalid order argument (only 1-preorder, or 2-inorder): %d ", order);
}



void print_array(int arr[], int N)
{
	int i = 0;
	printf("\n");
	for (i =0; i<N; i++)
	{
		printf("%d ", arr[i]);
	}
	printf("\n");
}


/**
 * You may change this function, assuming you will not hardcode it. If your 
 * char** words has a structure that is different from what is assumed here, you can 
 * modify it to work for your structure.
 * 
 * @param words
 * @param num_words
 */
void print_strings(char** words, int num_words)
{
    int i;
	printf("\n");
    for (i = 0; i< num_words; i++) 
    {        
        printf("%s\n", words[i]);
    }
    printf("\n");
}





// Fill out the code for functions below:


tree_link tree_from_array_preorder(Item arr[], int N)  
{   
    int i = 0;
    tree_link tree = tree_from_array_preorder_aux(arr,&i,N);
    return tree;
}

tree_link tree_from_array_preorder_aux(Item arr[], int *pos, int N)  
{ 
    tree_link branch = NULL;
    if(*pos == N) return NULL;
    if(arr[*pos] != 0)
    {
        branch = malloc(sizeof(tree_link));
        branch->item = arr[*pos];
        *pos += 1;
        branch->left =  tree_from_array_preorder_aux(arr,pos,N);
        *pos += 1;
        branch->right = tree_from_array_preorder_aux(arr,pos,N);
        
    }
    return branch;
}

void free_tree(tree_link root) 
{	
    if(root == NULL) return;
    free_tree(root->left);
    free_tree(root->right);
    free(root);
}

// note that this will work also for when both left and right are NULL.
int count_one_child(tree_link root) 
{
    if (root == NULL) return 0;
    int l = count_one_child(root->left);
    int r = count_one_child(root->right);
    if( (root->left == NULL && root->right != NULL) || (root->left != NULL && root->right == NULL))
    {
        return l+r+1;
    }
    else return l+r;
}

// A non-recursive implementation is easier.
tree_link tree_from_array_level(Item arr[], int N) 
{
    int i;
    tree_link branch = NULL;
    tree_link tree[N];
    for(i = 0; i < N; i++)
    {
        tree[i] = buildNode(arr[i]);
    }
    for(i = 0; (2*i)+1 < N; i++)
    {
        tree[i]->left = tree[(2*i)+1];
        if ( (2*i)+2 >= N) break;
        tree[i]->right = tree[(2*i)+2];
    }
    return tree[0];
}

tree_link buildNode(Item i)
{
    tree_link branch = malloc(sizeof(tree_link));
    branch->item = i;
    branch->left = NULL;
    branch->right = NULL;
    return branch;
}

void free_words(char** words, int num_words)
{
    int i;
    for (i=0;i < num_words; i++)
        {
            free(words[i]);
        }
    free(words);
}

char** read_from_file(char* fname, int * size)  
{    
    FILE * fp;
    int allocVal = N_MAX;
    char ** fileInfo = malloc(N_MAX * sizeof(char*));
    char **temp;
    *size = 0;
    char buffer[1001],tempBuff[1001],tempBuff2tempBuffHarder[1001];
    char * del = "\n";
    char * del2delHarder = "\r";
    if ( (fp = fopen(fname,"r") ) == NULL)
   	{
        printf("Unable to open %s\n",fname);
        exit(1);
    }
    while (fgets(buffer, sizeof(buffer), fp) != NULL)
    {
        if(*size == allocVal)
        {
            allocVal = (allocVal + N_MAX);
            temp = realloc(fileInfo,allocVal*sizeof(char*));
            if(temp != NULL)
            {
                fileInfo = temp;
            }
            else
            {
                printf("unable to reallocate\n");
                exit(1);
            }
         }
         fileInfo[*size] = malloc( (strlen(buffer)+1) * sizeof(char*) );
         strcpy(tempBuff,strtok(buffer,del));
         strcpy(tempBuff2tempBuffHarder,strtok(tempBuff,del2delHarder));
         strcpy(fileInfo[*size],tempBuff2tempBuffHarder);
         *size += 1;
    }
    close(fp);
    return fileInfo;
}


void len_sort(char** words, int num_words)
{
    int i;
    int unsorted;
    char * temp;
    do
    {   
        unsorted = 0;
        for(i = 0; i < num_words-1;i++)
        {
           if(strlen(words[i]) > strlen(words[i+1]))
           {
               temp = words[i+1];
               words[i+1] = words[i];
               words[i] = temp;
               unsorted = 1;
           }
        }
        
    }while(unsorted == 1);
}
