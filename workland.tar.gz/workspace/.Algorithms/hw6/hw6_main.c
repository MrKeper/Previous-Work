#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "hw6.h"

/* 
gcc -o mytree hw6_main.c hw6.c
./hw6
*/

void test_preorder(int arr[], int N)
{	
	printf("\nBuilding a tree, in preorder, from array:");
	print_array(arr, N);		
	tree_link my_tree = tree_from_array_preorder(arr, N);	
	printf("rotated tree:\n\n");
	print_tree(my_tree,0,2);    // tree on the side -like	
	printf("As a directory:\n\n");
	print_tree(my_tree,0,1);  // directory-like
	free_tree(my_tree);
}


void test_levelorder(int arr[], int N)
{
    printf("\n\nBuilding a tree, in level-order, from array:");
	print_array(arr, N);	
	tree_link my_tree = tree_from_array_level(arr, N);
	print_tree(my_tree,0,2);    // tree on the side -like
	free_tree(my_tree);
}


void test_trees()
{
	int arr[100]  = {1,2,3,0,0,4,0,0,0};
	int arr0[100] = {1,2,3,0,0,4,0,6,0,0,9,5,8,0,0,0,0};
	int arr1[100] = {1,2,3,0,0,4,0,0,9,0,0};
	int arr2[100] = {2,3,4};
	int arr3[100] = {1,2,3,4,5,6,7,8,9,10};	
    int arr4[100] = {5,0,9,100,7,6,15,0,9,2};
    
	test_preorder(arr, 9);	

	test_preorder(arr1, 11);

	test_preorder(arr0, 17);
    tree_link my_tree = tree_from_array_preorder(arr0, 17);	
    
	int ct = count_one_child(my_tree);
	printf("\nNumber of nodes with exactly one child in the above tree: %d\n", ct);	
	free_tree(my_tree);
		
	test_levelorder(arr2, 3);	
	
	test_levelorder(arr3, 10);
}







void test_sort(char* fname)
{
    int i;   
    int num_words;
    char** words = read_from_file(fname, &num_words);
    
    printf("\n ORIGINAL data:\n");
    print_strings(words, num_words);
    
    len_sort(words, num_words);  // sort the array
    
    printf("\n SORTED data:\n");    
    print_strings(words, num_words);    

    free_words(words, num_words);
}


int main()
{
	test_trees();
	
        // test sorting array of string by string length
        test_sort("data1.txt");
        test_sort("data2.txt");  
        return 0;
}