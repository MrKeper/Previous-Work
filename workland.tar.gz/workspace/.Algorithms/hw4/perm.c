#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "perm.h"


int power(int N,int powerVal);
void permAndPrint(int base,int length,int line_count);
int task_1_helper(int N, int * solutions);
void perm_rec_1_helper(int length, int base, int value);
int ** perm_rec_2_helper(int ** data, int row,int col,int base);


// Implement the functions below. You can add any helper function you need.
int task_1(int N)
{
    if(N < 0)
    {
        printf("Error Message: Task 1 , N less than 0\n");
        return 0;
    }
     int i;
     int * t1 = malloc(sizeof(int) * (N+2));
     for (i = 0; i <= N+1; i++) t1[i] = -1;
     int result = task_1_helper(N,t1);
     free(t1);
     return result;
}

int task_1_helper(int N, int * solutions)
{
     if (solutions[N] != -1) return solutions[N];
     int result;
     if(N == 0 || N == 1)
     {
        result =  1;
        solutions[N] = result;
        return result;
     }
     else if(N%2 != 0)
     {
        result = task_1_helper(N+1,solutions)-2;
        solutions[N] = result;
        return result;
     }
     else
     {
        result = task_1_helper(N/2,solutions) + task_1_helper(N-2,solutions);
        solutions[N] = result;
        return result;
     }
     solutions[N] = result;
     return result;
}


void free_matrix_ptr(matrix_ptr my_matrix)
{
    int i;
    for(i = 0;i<my_matrix->rows;i++)
    {
        free(my_matrix->data_arr[i]);
    }
   free(my_matrix -> data_arr);
    free(my_matrix);
}


void perm_rec_1(int N, int nr_vals)
{
    if(N < 0)
    {
        printf("Error Message: perm_rec_1 , N less than 0\n");
        return;
    }
    if(nr_vals < 0)
    {
        printf("Error Message: perm_rec_1 , nr_vals less than 0\n");
        return;
    }
  perm_rec_1_helper(N,nr_vals,power(nr_vals,N)-1);
}

void perm_rec_1_helper(int length, int base, int value)
{
    if(value != 0)
    {
        perm_rec_1_helper(length,base,value-1);
    }

        int line[length];
        int i,insertVal,currentVal,pos=0;
        for(i = 0;i < length;i++)
        {
            line[i] = 0;
        }
        currentVal = value;
        while(currentVal != 0)
        {
            insertVal = currentVal%base;
            line[pos] = insertVal;
            currentVal = currentVal/base;
            pos++;
        }
        for(i = length-1;i>=0;i--) printf("%d ",line[i]);
        printf("\n");
    
}

matrix_ptr perm_rec_2(int N, int nr_vals) 
{
    if(N < 0)
    {
        printf("Error Message: perm_rec_2 , N less than 0\n");
        return;
    }
    if(nr_vals < 0)
    {
        printf("Error Message: perm_rec_2 , nr_vals less than 0\n");
        return;
    }
    matrix_ptr res = malloc(sizeof(matrix_ptr));
    int i;
    int ** arr;
    res -> rows = power(nr_vals,N);
    res -> cols = N;
    arr = (int **)malloc(sizeof(int *) *  res->rows);
	arr[0] = (int *)malloc(sizeof(int) * res->cols * res->rows);
	for(i = 0; i < res->rows; i++)
	{
	    arr[i] =  malloc((res->cols)*sizeof(int));
	}
    (res->data_arr) = perm_rec_2_helper(arr,(res->rows)-1,(res->cols),nr_vals);
    return res;
}

int ** perm_rec_2_helper(int ** data, int row,int col,int base)
{
    if(row != 0)
    {
        data = perm_rec_2_helper(data,row-1,col,base);
    }
    int i,insertVal,currentVal;
    currentVal = row;
    for(i = col-1;i >= 0;i--)
    {
        insertVal = currentVal%base;
        data[row][i] = insertVal;
        currentVal = currentVal/base;
    }
    return data;
}


void perm_iter(int N, int nr_vals)
{
    if(N < 0)
    {
        printf("Error Message: perm_iter , N less than 0\n");
        return;
    }
    if(nr_vals < 0)
    {
        printf("Error Message: perm_iter , nr_vals less than 0\n");
        return;
    }
    int i;
    int lineCount = power(nr_vals,N);
    permAndPrint(nr_vals,N,lineCount);
}

int power(int N,int powerVal)
{
    int i;
    int intialVal = N;
    for(i=1;i<powerVal;i++)
    {
        N = N*intialVal;
    }
    return N;
}

void permAndPrint(int base,int length,int line_count)
{
    int i,k,pos,currentVal,insertVal;
    int line[length];
    for(i=0;i<length;i++) line[i] = 0;
    for(i=0;i<line_count;i++)
    {
        pos = 0;
        currentVal = i;
        while(currentVal != 0)
        {
            insertVal = currentVal%base;
            line[pos] = insertVal;
            currentVal = currentVal/base;
            pos++;
        }
        for(k=length-1;k>=0;k--)
        {
            printf("%d ",line[k]);
        }
        printf("\n");
    }
}