/************************************************************************
* Keenan Parker
* 10-31-2015
* 1001024878
* CSE 2320-001
* 
* 
* Homework 5 - Dynamic Programming - edit distance w/ string alingment
************************************************************************/
#include<stdio.h>
#include<string.h>
int edit_distance(char* s1, char* s2);
void insertCharacter(char * str,int pos);
int max(int a, int b);
int min(int a, int b);


int main()
{
    int edit_dist;
    char s1 [1001];
    char s2 [1001];
    //printf("Enter 2 Strings: ") ;
    while(scanf("%s %s",s1,s2))
    {
        if(strcmp(s1,"-1")  == 0 && strcmp(s2,"-1") == 0) break;
        printf("String 1: %s\nString 2: %s\n",s1,s2);
        edit_dist = edit_distance(s1,s2);
        printf("distance: %d\n\n",edit_dist);
        //printf("String 1: %s\nString 2: %s\n\n",s1,s2);

    }
}
int edit_distance(char* s1, char* s2)
{
    int distance,i,k;
    int insertVal;
    int insertion,deletion,match,current,track;
    int row = strlen(s1)+1;
    int col = strlen(s2)+1;
    int arr[row][col];
    char editPath[max(row,col)];
    char tempS1[1001];
    strcpy(tempS1,s1);
    char tempS2[1001];
    strcpy(tempS2,s2);
    for(i = 0;i<row;i++) arr[i][0] = i;
    for(i = 0;i<col;i++) arr[0][i] = i;
    for(i=1;i<row;i++)
    {
        for(k=1;k<col;k++)
        {
            insertVal = arr[i-1][k-1];
            if(insertVal > arr[i][k-1]) insertVal = arr[i][k-1];
            if(insertVal > arr[i-1][k]) insertVal = arr[i-1][k];
            insertVal++;
            if(s1[i-1] == s2[k-1]) insertVal = arr[i-1][k-1];
            arr[i][k] = insertVal;
        }
    }
    track = max(row,col)-1;
    i = row;
    k = col;
    while(i>0 && k>0)
    {
           // printf("s1: %c, s2: %c\n",s1[i-1],s2[k-1]);
            insertion = arr[i-1][k];
            deletion = arr[i][k-1];
            match = arr[i-1][k-1];
            if(s1[i-1] == s2[k-1])
            {
                k--;
                i--;
                editPath[track] = '.';
            }
            else if(match < deletion && match < insertion)
            {
                i--;
                k--;
                editPath[track] = 's';
            }
            else if(deletion < insertion)
            {
                k--;
                editPath[track] = 'd';
            }
            else
            {
                i--;
                editPath[track] = 'i';
            }
            track--;
        
    }
    distance = arr[row-1][col-1];
    for(i=0;i<max(row,col)-1;i++)
    {
       printf("%c ",editPath[i]);
       if(editPath[i] != '.')
       {

       }
    }
    printf("\n");
    strcpy(s1,tempS1);
    strcpy(s2,tempS2);
    return distance;
}

void insertCharacter(char * str,int pos)
{
    int length;
    char tempStr[1001] = {};
    strncpy(tempStr,str,pos);
    length = strlen(tempStr);
    strcpy(tempStr+length,"-");
    length++;
    strcpy(tempStr+length,str+pos);
    strcpy(str,tempStr);
}

int max(int a, int b)
{
    if(a > b)
        return a;
    else
        return b;
}

int min(int a, int b)
{
    if(a < b)
        return a;
    else
        return b;
}

/*

print array 

     for(i=0;i<row;i++)
    {
        for(k=0;k<col;k++)
        {
            printf("%d ",arr[i][k]);
        }
        printf("\n");
    }
    int edit_distance(char* s1, char* s2)
{
    int distance,i,k;
    int insertVal;
    char tempS1[256];
    strcpy(tempS1,s1);
    char tempS2[256];
    strcpy(tempS2,s2);
    int test;
    int row = strlen(s1)+1;
    int col = strlen(s2)+1;
    int arr[row][col];
    for(i = 0;i<row;i++) arr[i][0] = i;
    for(i = 0;i<col;i++) arr[0][i] = i;
    for(i=1;i<row;i++)
    {
        for(k=1;k<col;k++)
        {   
            test = 1;
           // printf("%c %c\n",s1[i],s2[k]);
            insertVal = arr[i-1][k-1];
            if(insertVal > arr[i][k-1]) insertVal = arr[i][k-1];
            if(insertVal > arr[i-1][k]) insertVal = arr[i-1][k];
            insertVal++;
            if(s1[i-1] == s2[k-1])
            {
                insertVal = arr[i-1][k-1];
                test = 0;
            }
            arr[i][k] = insertVal;
            if(test != 0)
            {
                if(strlen(tempS1) > strlen(tempS2))
                {
                    insertCharacter(tempS2,k);
                }
                else if(strlen(tempS1) < strlen(tempS2))
                {
                    insertCharacter(tempS1,i);
                }
            }
        }
    }
    
    distance = arr[row-1][col-1];
       strcpy(s1,tempS1);
    strcpy(s2,tempS2);
    return distance;
}

*/

