#include<stdio.h>

int foo(int a, int b);


int main()
{
    printf("%d\n",foo(75,324));
}

 int foo(int a, int b)
{
  if (a > b) return 0;
  if (a == b) return b;
  return a + foo(a+1, b);
}
