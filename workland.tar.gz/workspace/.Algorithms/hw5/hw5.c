/*******************************************************************
* Keenan Parker
* 10-31-2015
* 1001024878
* CSE 2320-001
* 
* 
* Homework 5 - Dynamic Programming - edit distance
*******************************************************************/
#include<stdio.h>
#include<string.h>
int edit_distance(char* s1, char* s2);

int main()
{
    int edit_dist;
    char s1 [1001];
    char s2 [1001];
    printf("Enter 2 Strings: ") ;
    while(scanf("%s %s",s1,s2))
    {
         printf("\nString 1: %s\nString 2: %s\n",s1,s2);
        if(strcmp(s1,"-1")  == 0 && strcmp(s2,"-1") == 0) break;
        edit_dist = edit_distance(s1,s2);
        printf("distance: %d\n",edit_dist);
        printf("Enter 2 Strings: ") ;

    }
}

int edit_distance(char* s1, char* s2)
{
    int distance,i,k;
    int insertVal;
    int row = strlen(s1)+1;
    int col = strlen(s2)+1;
    int arr[row][col];
    for(i = 0;i<row;i++) arr[i][0] = i;
    for(i = 0;i<col;i++) arr[0][i] = i;
    for(i=1;i<row;i++)
    {
        for(k=1;k<col;k++)
        {
            insertVal = arr[i-1][k-1];
            if(insertVal > arr[i][k-1]) insertVal = arr[i][k-1];
            if(insertVal > arr[i-1][k]) insertVal = arr[i-1][k];
            insertVal++;
            if(s1[i-1] == s2[k-1]) insertVal = arr[i-1][k-1];
            arr[i][k] = insertVal;
        }
    }
    
    distance = arr[row-1][col-1];
       
    return distance;
}

/*

print array 

     for(i=0;i<row;i++)
    {
        for(k=0;k<col;k++)
        {
            printf("%d ",arr[i][k]);
        }
        printf("\n");
    }
*/