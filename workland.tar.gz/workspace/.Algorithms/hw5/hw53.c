/*******************************************************************
* Keenan Parker
* 10-31-2015
* 1001024878
* CSE 2320-001
* 
* 
* Homework 5 - Dynamic Programming - edit distance
*******************************************************************/
#include<stdio.h>
#include<string.h>
int edit_distance(char* s1, char* s2);
int min(int a, int b);


int main()
{
    int edit_dist;
    char s1 [256];
    char s2 [256];
    printf("Enter 2 Strings: ") ;
    while(scanf("%s %s",s1,s2))
    {
        if(strcmp(s1,"-1")  == 0 && strcmp(s2,"-1") == 0) break;
        edit_dist = edit_distance(s1,s2);
        printf("distance: %d\nString 1: %s\nString 2: %s\n",edit_dist,s1,s2);
        printf("Enter 2 Strings: ") ;

    }
}

int edit_distance(char* s1, char* s2)
{
    int distance,i,k;
    int insertVal;
    int insertion,deletion,subsitution,possibleMin,minVal;
    int row = strlen(s1)+1;
    int col = strlen(s2)+1;
    int arr[row][col];
    for(i = 0;i<row;i++) arr[i][0] = i;
    for(i = 0;i<col;i++) arr[0][i] = i;
    for(i=1;i<row;i++)
    {
        for(k=1;k<col;k++)
        {
           // printf("%c %c\n",s1[i],s2[k]);
           if(s1[i-1] == s2[k-1])
           {
                subsitution = arr[i-1][k-1];
                insertion = arr[i][k-1];
                deletion = arr[i-1][k];
                possibleMin = min(insertion+1,deletion+1);
                minVal = min(subsitution,possibleMin);
           }
           else
           {
                insertion = arr[i][k-1];
                deletion = arr[i-1][k];
                minVal = min(deletion+1,insertion+1);
           }
           
            arr[i][k] = minVal;
        }
    }
    
    distance = arr[row-1][col-1];
         for(i=0;i<row;i++)
    {
        for(k=0;k<col;k++)
        {
            printf("%d ",arr[i][k]);
        }
        printf("\n");
    }
    return distance;
}

int min(int a, int b)
{
    if(a>b)
        return b;
    else
        return a;
}

/*

print array 

     for(i=0;i<row;i++)
    {
        for(k=0;k<col;k++)
        {
            printf("%d ",arr[i][k]);
        }
        printf("\n");
    }
    
    
int edit_distance(char* s1, char* s2)
{
    int distance,i,k;
    int insertVal;
    int row = strlen(s1)+1;
    int col = strlen(s2)+1;
    int arr[row][col];
    for(i = 0;i<row;i++) arr[i][0] = i;
    for(i = 0;i<col;i++) arr[0][i] = i;
    for(i=1;i<row;i++)
    {
        for(k=1;k<col;k++)
        {
           // printf("%c %c\n",s1[i],s2[k]);
            insertVal = arr[i-1][k-1];
            if(insertVal > arr[i][k-1]) insertVal = arr[i][k-1];
            if(insertVal > arr[i-1][k]) insertVal = arr[i-1][k];
            insertVal++;
            if(s1[i-1] == s2[k-1]) insertVal = arr[i-1][k-1];
            arr[i][k] = insertVal;
        }
    }
    
    distance = arr[row-1][col-1];
         for(i=0;i<row;i++)
    {
        for(k=0;k<col;k++)
        {
            printf("%d ",arr[i][k]);
        }
        printf("\n");
    }
    return distance;
}
    
*/