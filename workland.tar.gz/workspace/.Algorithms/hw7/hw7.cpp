/*******************************************************************
* Keenan Parker
* 12/4/2015
* 1001024878
* CSE 2320-001
* 
* 
* Homework 7 -Graphs
* Complation Instructions: 
* g++ -o i1 instr_1.cpp hw7.cpp graph_matrix.cpp twoD_arrays.cpp list.cpp
* ./i1 < g2.txt 
*******************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "graph.h"
#include "list.h"
#include "hw7.h"
int find(int object, int id[]);
void set_union(int set_id1, int set_id2, int id[], int size, int size_arr[]);
int countConnected_helpCount(int id[], int vertexNum);
void countConnected_helpUnion(graph g,int v,int id[]);

/*
Task 1 (16 pts.) - Connected Components with Union-Find

This solution needs to use a Union-Find algorithm to keep track of connected components. No credit will be given if union-find is not used for this purpose. 
Write a function countConnected_UF(graph G) that takes as input a graph, G, and returns the number of connected components in G.
A connected component is a subgraph of G where there is a path between any two vertices. 
If G1 and G2 are two different connected components of G, there is no edge between G1 and G2. Use any of the union-find algorithms to count how many connected components are in G.
Note that you only need to count them. You do not need to worry about the efficiency of the union-find algorithm so you can use any of the variations.


What your function needs to do is:

use G and functions provided in graph.h to be able to generate pairs of vertices that are connected. (Use the function that returns a list of neighbours for a vertex.)
use the pairs generated above as pairs for the union-find algorithm.
Modify (very little) the union-find algorithm to keep track of current number of connected components. 
Note that when you start, all nodes are disconnected so each node is a connected component and so there are N connected components.
Whenever you do a union operation, you will have one less connected component.
*/

int  countConnected_UF(graph g)
{
    
    if(g == NULL) return 0;
    int v = numVertices(g);
    int id[v];
    countConnected_helpUnion(g,v,id);
    return countConnected_helpCount(id,v);
}

void countConnected_helpUnion(graph g,int v,int id[])
{
    int p, q, i,k,p_id, q_id,vertexNumber,neighborNumber, size_arr[v];
    for (i = 0; i < v; i++) 
    {
      id[i] = i;
      size_arr[i] = 1; 
    }
    link tempLink;
    for(i = 0; i < v;i++)
    {
        list l = vertexNeighbors(g,i);
        if(computeLength(l) == 0)
        {
            continue;
        }
        tempLink = getFirst(l);
        vertexNumber = i;
        for(k = 0; k < computeLength(l); k++)
        {
            if(k != 0) 
            {
                tempLink = getLinkNext(tempLink);
            }
            neighborNumber = getLinkItem(tempLink);
            p_id = find(vertexNumber, id);
            q_id = find(neighborNumber, id);
            if (p_id == q_id) 
            {
              continue;
            }
            set_union(p_id, q_id, id, v, size_arr);	    
            printf(" %d %d newly connected\n", vertexNumber, neighborNumber);
        }
        free(l);
    }
}

int find(int object, int id[])
{
  int next_object;
  next_object = id[object];

  while (next_object != id[next_object])
  {	
    next_object = id[next_object];
  }

  return next_object;
}

void set_union(int set_id1, int set_id2, int id[], int size, int size_arr[])
{
  if (size_arr[set_id1] < size_arr[set_id2])
  {
	id[set_id1] = set_id2;
	size_arr[set_id2] = size_arr[set_id1]  + size_arr[set_id2];
  }
  else
  {
	id[set_id2] = set_id1;
	size_arr[set_id1] = size_arr[set_id1]  + size_arr[set_id2]; 
  }
}

int countConnected_helpCount(int id[], int vertexNum)
{
    int connectedComponents = 0;
    int countArr[vertexNum];
    int i,k;
    for(i = 0; i < vertexNum;i++) countArr[i] = -1;
    int j=0,temp,check;
    for(k = 0; k < vertexNum; k++)
    {
        temp = id[k];
       for(int i = 0; i < vertexNum;i++)
       {
           if(temp == countArr[i])
           {
               check = 1;
           }
       }
       if(check != 1)
       {
           countArr[j] = temp;
           j++;
       }
       check = 0;
    }
    for(k = 0; k < vertexNum; k++)
    {
        if(countArr[k] != -1)
        {
            connectedComponents++;
        }
    }
    return connectedComponents;
}

/*
Task 2 (15 pts.) - Label Connected Components with Graph Search6

This solution needs to use a Graph Search (depth first or breadth first) algorithm to label connected components. No credit will be given if graph search is not used for this purpose. 
Write a function labelConnected_Search(graph G, int* num_components) that takes as input a graph, G, and returns the number of connected components in G.
A connected component is a subgraph of G where there is a path between any two vertices. If G1 and G2 are two different connected components of G, there is no edge between G1 and G2. 
Use any of the graph search algorithms to count and label the connected components in G. Use the convention:
0 - unvisited and unlabelled node
positive integer, k, visited node, part of connected component k. 
For counting the connected components you can start from 1 and increment by 1 for each new connected component. 
All the nodes in the first connected component will have label 1, all the nodes in the second one will have label 2 and so on.
*/

int *  labelConnected_Search(graph g, int* comp_count)
{
    int vertexCount = numVertices(g);
    int i;
    int * labels = (int*)malloc(vertexCount*sizeof(int));
    int * visited = (int*)malloc(vertexCount*sizeof(int));
    for(i = 0; i < vertexCount;i++) 
    {
        labels[i] = 0;
        visited[i] = 0;
    }
    int currentLabel = 0;
    
    int check = 1;
    while(check == 1)
    {
        check = 0;
        for(i = 0;i<vertexCount;i++)
        {
            if(visited[i] == 0)
            {
                check = 1;
                currentLabel++;
                depth_first(g,labels,&currentLabel,visited,i);
                break;
            }
        }
    }
    
    *comp_count = currentLabel;
    return labels;
}

void depth_first(graph g, int * labels, int * curr_label,int * visited, int V)
{
    visited[V] = 1;
    labels[V] = *curr_label;
    list vNeighbors = vertexNeighbors(g,V);
    if(vNeighbors == NULL){ return;}
    int l = getLength(vNeighbors);
    int i,N;
    link vlink = getFirst(vNeighbors);
    for(i = 0; i < l; i++)
    {   
        N = getLinkItem(vlink);
        if(visited[N] != 1)
        {
            depth_first(g,labels,curr_label,visited,N);
        }
        vlink = getLinkNext(vlink);
    }
    free(vNeighbors);
}

/*
Task 3 (21 pts.)

Write a function maxEdges(int ** adjacencies, int V, int* mx_count, int* v_index) that takes as input the adjacency matrix of a graph, an integer V specifying the number of vertices in the graph and two pointers: mx_count and v_index. 
The function should find the vertex that has the largest number of neighbours and set v_index to be the index of that vertex and mx_count to be the number of neighbours.
If there are two vertices that have the same largest number of neighbours, the one with the smaller index should be reported.
*/

void maxEdges(int ** adj, int V, int *mx_count, int *v_index)
{
    int i,k;
    int max  = 0;
    *mx_count = 0;
    *v_index = V;
    for(i = V-1; i >= 0;i--)
    {
        for(k = 0; k < V; k++)
        {
            if(adj[i][k] != 0)
            {
                max++;
            }
        }
        if(max > *mx_count)
        {
            *mx_count = max;
        }
       if(max == *mx_count)
        {
            *v_index = i;
        }
        max = 0;
    }
}

/*
Task 4 (21 pts.)

(This is Problem 3.74 from the textbook).
Write a function countConnectors(int ** adjacencies, int A, int B, int V) that takes as input the adjacency matrix of graph, two integers specifying vertices A and B, and an integer V specifying the number of vertices in the graph. 
The function should return the number of vertices in the graph that serve as connectors between A and B. A vertex C is called a "connector between A and B" if and only if there is an edge from A to C and from C to B. You can assume that the graph is undirected. 
To make the program easier, since self edges are not added by build_graph, they should not be counted. For example for the graph in g2.txt, the number of connectors between vertex 0 and vertex 1 is 1 (only vertex 3 is a connector).
*/

int countConnectors(int ** adj, int A, int B, int V)
{
    int i,connectorCount = 0;
    for(i = 0; i < V; i++)
    {
        if(adj[A][i] == 1 &&  adj[B][i] == 1)
        {
            connectorCount += 1;
        }
    }

    return connectorCount;
}

/*
Task 5 (25 pts.)

Write a function int sameNeighbors(graph g, int v1, int v2) that:
Returns 1 if vertices v1 and v2 have exactly the same set of neighbors.
Returns 0 otherwise.
*/

int sameNeighbors(graph g, int v1, int v2)
{
    list v1Neighbors = vertexNeighbors(g,v1);
    list v2Neighbors = vertexNeighbors(g,v2);
    if(v1Neighbors == NULL || v2Neighbors == NULL) return 0;
    int v1Length = computeLength(v1Neighbors);
    int v2Length = computeLength(v2Neighbors);
    if(v1Length != v2Length) return 0;
    if(v1Length == 0) return 1;
    int i,k;
    int check = 0;
    link v1Link,v2Link;
    int v1Item,v2Item;
    v1Link = getFirst(v1Neighbors);
    v2Link = getFirst(v2Neighbors);
    for(i = 0; i < v1Length; i++)
    {
        v1Item = getLinkItem(v1Link);
        if(v2Item == v2)
        {
            v1Link = getLinkNext(v1Link);
            check = 0;
            continue;
        }
        for(k = 0; k < v2Length; k++)
        {
            v2Item = getLinkItem(v2Link);
            if(v2Item == v1Item || v2Item == v1)
            {
                check = 1;
            }
            v2Link = getLinkNext(v2Link);
        }
        if(check != 1)
        {
            return 0;
        }
        v2Link = getFirst(v2Neighbors);
        v1Link = getLinkNext(v1Link);
        check = 0;
    }
    return 1;
}



/*
g++ -o i1 instr_1.cpp hw7.cpp graph_matrix.cpp twoD_arrays.cpp list.cpp
run:
./i1 < g2.txt

Calling the build_graph function...
Enter the number of vertices:
Enter the edges (by pairs, e.g.: 3 1):

THE GRAPH IS:
Vertex 0. Neighbors: 3 1
Vertex 1. Neighbors: 3 0
Vertex 2. Neighbors:
Vertex 3. Neighbors: 4 1 0
Vertex 4. Neighbors: 3


Do vertices 0 and 3 have the same neighbors?  0

Do vertices 0 and 1 have the same neighbors?  1

 Running connected components with Union Find:
 0 3 newly connected
 0 1 newly connected
 3 4 newly connected
Number of connected components: 2

 Running label connected components:

Number of connected components: 2

    v:label
    0:    1
    1:    1
    2:    2
    3:    1
    4:    1


Vertex with most edges: 3 (3)

The number of vertices that serve as direct connectors to 0 and 1 is: 1

--------------- After adding edge: 1-4

Vertex with most edges: 1 (3)

*/

