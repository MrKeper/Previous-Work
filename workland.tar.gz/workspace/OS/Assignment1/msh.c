/*
 * Name: Keenan Parker
 * ID #: 1001024878
 * Programming Assignment 1
 * Description: In this assignment you will write your own shell program, Mav
 * shell (msh), similar to bourne shell (bash), c-shell (csh), or korn
 * shell (ksh). It will accept commands, fork a child process and
 * execute those commands. The shell, like csh or bash, will run and
 * accept commands until the user exits the shell. 
 */
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <signal.h>

char ** splitInput(char buffer[], int * inputCount);
void freeInput(char ** in, int inputCount);
void childProcess(char ** input, int inputCount);
void handle_signal (int sig);
void addPidToEnd(int  * pidArray, int newPid);
void showPid(int pidArray[10]);
void changeDirectory(char ** input, int inputCount);
char ** splitDirectory(char cwd[], int * count);
void free_dir(char ** dir, int count);


int main( void ) 
{
    struct sigaction block;
    char buffer [255];
    char tempBuff[255];
    pid_t pid;
    char ** input;
    int inputCount;
    int lastTenPid[10] = {0};
    int pidCount = 0;
    memset (&block, '\0', sizeof(block));
    block.sa_handler = &handle_signal;
    sigaction(SIGINT , &block, NULL); 
    sigaction(SIGTSTP , &block, NULL); 
    while(1)
    {
        memset(buffer,0,255);
	    fflush(NULL);
        inputCount = 0;
        printf("msh> ");
        fgets (buffer, 255, stdin);
        strcpy(tempBuff,buffer);
    	if(strlen(tempBuff) == 0)
    	{
    	    continue;
    	}
        if(strcmp(strtok(tempBuff," "),"\n") == 0) // checks for blank input to ignore.
        {
            continue;
        }
        if(strcmp(strtok(tempBuff,"\n"),"quit") == 0) 
        {
            exit(0);
        }
        if(strcmp(strtok(tempBuff,"\n"),"exit") ==  0)
        {
            exit(0);
        }
        if(strcmp(strtok(tempBuff,"\n"),"showpid") ==  0)
        {
            showPid((lastTenPid));
            continue;
        }
        input = splitInput(buffer,&inputCount);
        if(inputCount == 7)
        {
            printf("Invalid Input: to many arguments besides command (max 5)\n");
            continue;
        }
        if(strcmp(input[0],"cd") == 0)
        {
            changeDirectory(input,inputCount);
            freeInput(input, inputCount);
            continue;
        }
        pid = fork();
        if(pid == 0)
        {
            childProcess(input,inputCount);
        }
        else if(pid > 0)
        {
            if(pidCount == 10)
            {
                //add new pid to end
                addPidToEnd(lastTenPid,pid);
            }
            else
            {
                lastTenPid[pidCount] = pid;
                pidCount++;
            }
            wait(NULL);
	    freeInput(input,inputCount);
        }
        else
        {
            perror("Failure in Fork");
            exit(EXIT_FAILURE);
        }
    }
  return 0 ;
}


/*
 * Function: splitInput
 * Parameter(s): char buffer[], a 255 char array of char that contains
 * the input from the user.
 * Returns: An array of the input split by " "(spaces);
 * Description: Takes the input from the user and splits it so that the 
 * program can operate on the input.
*/
char ** splitInput(char buffer[], int * inputCount)
{
    buffer = strtok(buffer,"\n");
    char ** results = (char**)malloc(6 * sizeof(char*));
    int i =0;
    char * token = strtok(buffer," ");
    while(token != NULL && *inputCount < 6)
    {
        *inputCount = *inputCount + 1;
        results[i] = (char*)malloc(strlen(token) + 1 * sizeof(char*));
        strcpy(results[i],token);
        token = strtok(NULL," ");
        i++;
    }
    if( *inputCount == 6 && token != NULL)
    {
        *inputCount = *inputCount +1;
    }
    return results;
}


/*
 * Function: freeInput
 * Parameter(s): char ** in, a array of strings used for input, now being passed in to be freed.
 * int inputCount, a count of how many strings are in char ** in.
 * Returns: nothing.
 * Description: Takes the a char ** array and frees it.
*/
void freeInput(char ** in, int inputCount)
{
    int i;
    for(i = 0; i < inputCount; i++)
    {
        free(in[i]);
    }
    free(in);
}

/*
 * Function: childProcess
 * Parameter(s): char ** in, a array of strings holding the input. inputCount is a int holding the number of input arguments. 
 * Returns: nothing.
 * Description: Takes the input and execls it ,ending the child process, and executing the task. If it is a valid task.
*/
void childProcess(char ** input, int inputCount)
{
    char cwd[255];
    char bin[255];
    char usrbin[255];
    char usrlocalbin[255];
    strcpy(bin,"/bin/");
    strcpy(usrbin,"/usr/bin/");
    strcpy(usrlocalbin,"/usr/local/bin/");
    strcat(bin,input[0]);
    strcat(usrbin,input[0]);
    strcat(usrlocalbin,input[0]);
    getcwd(cwd,255);
    strcat(cwd,"/");
    strcat(cwd,input[0]);
    if(inputCount == 1)
    {
        if(execl(cwd,input[0],NULL) == -1)
        {
            //perror(cwd);
        }
        if(execlp(usrlocalbin,input[0],NULL) == -1)
        {
           // perror(usrlocalbin);
        }
        if(execl(usrbin,input[0],NULL) == -1)
        {
           // perror(usrbin);
        }
        if(execlp(bin,input[0],NULL) == -1)
        {
            //perror(bin);
        }
        printf("%s: Command not found.\n",input[0]);
    }
    if(inputCount == 2)
    {
        if(execl(cwd,input[0],input[1],NULL) == -1)
        {
            //perror(cwd);
        }
        if(execlp(usrlocalbin,input[0],input[1],NULL) == -1)
        {
           // perror(usrlocalbin);
        }
        if(execl(usrbin,input[0],input[1],NULL) == -1)
        {
           // perror(usrbin);
        }
        if(execlp(bin,input[0],input[1],NULL) == -1)
        {
            //perror(bin);
        }
        printf("%s: Command not found.\n",input[0]);
    }
    if(inputCount == 3)
    {
        if(execl(cwd,input[0],input[1],input[2],NULL) == -1)
        {
            //perror(cwd);
        }
        if(execlp(usrlocalbin,input[0],input[1],input[2],NULL) == -1)
        {
           // perror(usrlocalbin);
        }
        if(execl(usrbin,input[0],input[1],input[2],NULL) == -1)
        {
           // perror(usrbin);
        }
        if(execlp(bin,input[0],input[1],input[2],NULL) == -1)
        {
            //perror(bin);
        }
        printf("%s: Command not found.\n",input[0]);
    }
    if(inputCount == 4)
    {
        if(execl(cwd,input[0],input[1],input[2],input[3],NULL) == -1)
        {
            //perror(cwd);
        }
        if(execlp(usrlocalbin,input[0],input[1],input[2],input[3],NULL) == -1)
        {
           // perror(usrlocalbin);
        }
        if(execl(usrbin,input[0],input[1],input[2],input[3],NULL) == -1)
        {
           // perror(usrbin);
        }
        if(execlp(bin,input[0],input[1],input[2],input[3],NULL) == -1)
        {
            //perror(bin);
        }
        printf("%s: Command not found.\n",input[0]);
    }
    if(inputCount == 5)
    {
        if(execl(cwd,input[0],input[1],input[2],input[3],input[4],NULL) == -1)
        {
            //perror(cwd);
        }
        if(execlp(usrlocalbin,input[0],input[1],input[2],input[3],input[4],NULL) == -1)
        {
           // perror(usrlocalbin);
        }
        if(execl(usrbin,input[0],input[1],input[2],input[3],input[4],NULL) == -1)
        {
           // perror(usrbin);
        }
        if(execlp(bin,input[0],input[1],input[2],input[3],input[4],NULL) == -1)
        {
            //perror(bin);
        }
        printf("%s: Command not found.\n",input[0]);
    }
    exit(EXIT_SUCCESS);
}

/*
 * Function: handle_signal
 * Parameter(s): int sig, code for SIGNAL
 * Returns: nothing
 * Description: just here to handle signal and print new line
*/
void handle_signal (int sig )
{
    printf("\n");
    return;
}

/*
 * Function: addPidToEnd
 * Parameter(s): int  * pidArray - an int array holding 10 ints which hold the last 10 pids / 0s for empty. 
 * int newPid holds the int representing the newpid.
 * Returns: nothing.
 * Description: updates the pid array with the new pid and moves down the current pids.
*/
void addPidToEnd(int  * pidArray, int newPid)
{
    int i;
    for(i = 0; i < 9; i++)
    {
        pidArray[i] = pidArray[i+1];
    }
    pidArray[9] = newPid;
}

/*
 * Function: showPid
 * Parameter(s): int pidArray[10] - an int array holding 10 ints which hold the last 10 pids / 0s for empty.
 * Returns:  nothing.
 * Description: prints the pid array.
*/
void showPid(int pidArray[10])
{
    int i;
    for(i = 0; i < 10; i++)
    {
        if(pidArray[i] == 0)
            break;
        printf("     %d\n",pidArray[i]);
    }
}

/*
 * Function: changeDirectory
 * Parameter(s): char ** input string array that contains the input from user, int inputCount is a int holding the number of input arguments.
 * Returns: nothing.
 * Description: takes input and uses chdri() to change to directory based on the input.
*/
void changeDirectory(char ** input, int inputCount)
{
    char cwd[255];
    char temp[255];
    getcwd(cwd,255);
    strcat(cwd,"/");
    char * token;
    char ** dir;
    int count = 0;
    int i;
    if(inputCount == 1)
    {
        token = strtok(cwd,"/");
        strcpy(temp,"/");
        strcat(temp,token);
        strcpy(cwd,temp);
        if(chdir(cwd) == -1)
        {
            printf("msh: cd: %s: No such file or directory",input[0]);
        }
    }
    if(inputCount == 2)
    {
        if(strcmp(input[1],"..") == 0)
        {
            dir = splitDirectory(cwd,&count);
            memset(temp,0,255);
            for(i = 0; i< count-1;i++)
            {
                strcat(temp,"/");
                strcat(temp,dir[i]);
            }
            chdir(temp);
            free_dir(dir,count);
        }
        else
        {
            strcat(cwd,input[1]);
            if(chdir(cwd) == -1)
            {
                printf("msh: cd: %s: No such file or directory\n",input[1]);
            }
        }
        
    }
    return;
}

/*
 * Function: splitDirectory
 * Parameter(s):char cwd[] is the current directory, which will be split. count is the pointer to the a int = 0; 
 * Returns: An array of strings that contains the directories 
 * Description: splits the current directory and returns an array containing the directory names.
*/
char ** splitDirectory(char cwd[], int * count)
{
    char ** results = (char**)malloc(1 * sizeof(char*));
    char ** temp;
    int i =0;
    char * token = strtok(cwd,"/");
    while(token != NULL)
    {
        *count = *count + 1;
        if(*count != 1)
        {
            temp = (char **)realloc(results, *count*sizeof(char*) );
            if(temp != NULL)
            {
                results = temp;
                temp = NULL;
            }
            else
            {
                printf("unable to reallocate\n");
                exit(EXIT_FAILURE);
            }
        }
        results[i] = (char*)malloc(strlen(token) + 1 * sizeof(char*));
        strcpy(results[i],token);
        token = strtok(NULL,"/");
        i++;
    }
    return results;
}

/*
 * Function: free_dir
 * Parameter(s): char ** dir, a array of strings used for input, now being passed in to be freed.
 * int count, a count of how many strings are in char ** dir.
 * Returns: nothing.
 * Description: Takes the a char ** array and frees it.
*/
void free_dir(char ** dir, int count)
{
    int i;
    for(i = 0; i < count; i++)
    {
        free(dir[i]);
        break;
    }
    free(dir);
}
