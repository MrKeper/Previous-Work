#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <time.h>

#define NUM_BLOCKS 4226
#define BLOCK_SIZE 8192
#define NUM_FILES  128
#define NUM_INODES 128
#define MAX_BLOCKS_PER_FILE 32
#define MAX_FILE_SIZE 262144

char ** parseInput(char buffer[], int * inputCount);
void freeInput(char ** in, int inputCount);
int df();
void list();
void init();
int findDataBlock();
int findFreeDirectoryEntry();
int findFreeInode();
void put(char * filename);
void get(char * filename);
void get_new(char * readfile, char * writefile);
void del(char * filename);
char * getMonth(int month);
int findDirIndex (char * filename);
void undelete(char * filename);

unsigned char data_blocks[NUM_BLOCKS][BLOCK_SIZE];
         int  used_blocks[NUM_BLOCKS];

struct directory_entry
{
  char * name;
  int    valid;
  int    inode_idx;
  int hasBeenUsed;
};

struct directory_entry *directory_ptr;

struct inode
{
  time_t data;
  int file_size;
  int valid;
  int blocks[MAX_BLOCKS_PER_FILE];  
};

struct inode * inode_array_ptr[NUM_INODES];

int main ()
{

  init();
  char buffer [255];
  char tempBuff[255];
  int inputCount;
  char ** input;
  int i;
  while(1)
    {
        memset(buffer,0,255);
        inputCount = 0;
	      fflush(NULL);
        printf("mfs> ");
        fgets (buffer, 255, stdin);
        strcpy(tempBuff,buffer);
        if(strlen(tempBuff) == 0) { continue;	}
        if(strcmp(strtok(tempBuff," "),"\n") == 0)     
        { 
          continue;
          
        }  
        if(strcmp(strtok(tempBuff,"\n"),"quit") == 0)  
        { 
          exit(0); 
        }
        if(strcmp(strtok(tempBuff,"\n"),"exit") ==  0) 
        { 
          exit(0);
        }
        input = parseInput(buffer,&inputCount);
        if(inputCount == 4)
        {
          printf("Invalid command\n");
          continue;
        }
        
        if(strcmp(input[0],"put") == 0)
        {
          if(inputCount == 3)
          {
            printf("Invalid command: Proper = put <filename>\n");
            continue;
          }
          put(input[1]);
          
        }
  
        if(strcmp(input[0],"get") == 0)
        {
          if(inputCount == 2)
          {
            get(input[1]);
          }
          else
          {
            get_new(input[1],input[2]);
          }
        }
        
        if(strcmp(input[0],"del") == 0)
        {
          if(inputCount == 3)
          {
            printf("Invalid command: Proper = del <filename>\n");
            continue;
          }
          del(input[1]);
        }
        
        if(strcmp(input[0],"undelete") == 0)
        {
          if(inputCount == 3)
          {
            printf("Invalid command: Proper = undelete  <filename>\n");
            continue;
          }
          undelete(input[1]);
        }
        
        if(strcmp(input[0],"list") == 0)
        {
          if(inputCount != 1)
          {
            printf("Invalid command: Proper = list\n");
            continue;
          }
          list();
        }
        
        if(strcmp(input[0],"df") == 0)
        {
          if(inputCount != 1)
          {
            printf("Invalid command: Proper = df\n");
            continue;
          }
          printf("%d bytes free.\n",df());
        }
        
    }
  
  return 0;
}

/*
 * Function: parseInput
 * Parameter(s): char buffer[], a 255 char array of char that contains
 * the input from the user.
 * Returns: An array of the input split by " "(spaces);
 * Description: Takes the input from the user and splits it so that the 
 * program can operate on the input.
*/
char ** parseInput(char buffer[], int * inputCount)
{
    buffer = strtok(buffer,"\n");
    char ** results = (char**)malloc(3 * sizeof(char*));
    int i =0;
    char * token = strtok(buffer," ");
    while(token != NULL && *inputCount < 4)
    {
        *inputCount = *inputCount + 1;
        results[i] = (char*)malloc(strlen(token) + 1 * sizeof(char*));
        strcpy(results[i],token);
        token = strtok(NULL," ");
        i++;
    }
    if( *inputCount == 3 && token != NULL)
    {
        *inputCount = *inputCount +1;
    }
    return results;
}

/*
 * Function: init
 * Parameter(s): N/A
 * Returns: N/A
 * Description: inits the various global variables
*/
void init ()
{

  int i;
  directory_ptr = (struct directory_entry*) &data_blocks[0];

  for( i = 0; i < NUM_FILES; i++ )
  {
     directory_ptr[i].valid = 0;
     directory_ptr[i].hasBeenUsed = 0;
  }

  int inode_idx = 0;
  for( i = 1; i < 130; i++ )
  {
    inode_array_ptr[inode_idx++] = (struct inode*) &data_blocks[i];
  }
}

/*
 * Function: findFreeDirectoryEntry
 * Parameter(s): N/A
 * Returns:  an int containing the index of a free directory if there is one
 *           or returns an -1 if there is no free DIR.
 * Description: read return;
*/
int findFreeDirectoryEntry( )
{
  int i;
  int retval = -1;
  for( i = 0; i < 128; i++ )
  {
    if( directory_ptr[i].valid == 0 )
    {
      retval = i;
      break;
    }
  }
  return retval;
}

/*
 * Function: findFreeInode
 * Parameter(s): N/A
 * Returns:  an int containing the index of a free inode if there is one
 *           or returns an -1 if there is no free indoe.
 * Description: read return;
*/
int findFreeInode( )
{
  int i;
  int retval = -1;
  for( i = 0; i < 128; i++ )
  {
    if( inode_array_ptr[i]->valid == 0 )
    {
      retval = i;
      break;
    }
  }
  return retval;
}

/*
 * Function: findDataBlock
 * Parameter(s): N/A
 * Returns:  an int containing the index of a free dataBlock if there is one
 *           or returns an -1 if there is no free dataBlock.
 * Description: uses the used_blocks array and finds the first block that == 0
*/
int findDataBlock( )
{
  int i;
  int retval = -1;
  for( i = 130; i < 4226; i++ )
  {
    if( used_blocks[i] == 0 )
    {
      retval = i;
      break;
    }
  }
  return retval;
}

/*
 * Function: df
 * Parameter(s): N/A
 * Returns: an int representing the remamnig disk space
 * Description: uses the used_blocks array and calculates the number
 *              of unsed blocks and returns that *BLOCK_SIZE
*/
int df()
{
  int i;
  int count = 0;
  for(i = 130; i < 4226; i++)
  {
    if(used_blocks[i] == 0)
    {
      count++;
    }
  }
  return count * BLOCK_SIZE;
}

/*
 * Function: list
 * Parameter(s): N/A
 * Returns: N/A
 * Description: prints out the current files in the file system and some meta-data
*/
void list()
{
  int i;
  int size;
  time_t tnd;
  int inode_index;
  int count = 0;
  struct tm * time_info;
  for( i = 0; i < NUM_FILES; i++ )
  {
    if(directory_ptr[i].valid != 0)
    {
      count++;
      inode_index = directory_ptr[i].inode_idx;
      size = inode_array_ptr[inode_index]->file_size;
      tnd =  inode_array_ptr[inode_index]->data;
      time_info = localtime ( &tnd );
      if(time_info->tm_min < 10)
      {
        printf("%-7d %s %d  %d:0%d  %s\n",size,getMonth(time_info->tm_mon),time_info->tm_mday,time_info->tm_hour,time_info->tm_min,directory_ptr[i].name);
      }
        else
      {
        printf("%-7d %s %d  %d:%d  %s\n",size,getMonth(time_info->tm_mon),time_info->tm_mday,time_info->tm_hour,time_info->tm_min,directory_ptr[i].name);
      }
        
    }
    
  }
  if(count == 0)
  {
    printf("list: No files found.\n");
  }
  return;
}

/*
 * Function: getMonth
 * Parameter(s): an int between 0-11
 * Returns: a char for the month that the int represents 
 * Description: Used to print Mons as char and not ints
*/
char * getMonth(int month)
{
  switch(month)
  {
    case 0:
      return "Jan";
      break;
    case 1:
      return "Feb";
      break;
    case 2:
      return "Mar";
      break;
    case 3:
      return "Apr";
      break;
    case 4:
      return "May";
      break;
    case 5:
      return "Jun";
      break;
    case 6:
      return "Jul";
      break;
    case 7:
      return "Aug";
      break;
    case 8:
      return "Sep";
      break;
    case 9:
      return "Oct";
      break;
    case 10:
      return "Nov";
      break;
    case 11:
      return "Dec";
      break;
    case 12:
      break;
  }
}


/*
 * Function: put
 * Parameter(s): an string containt the name for a file
 * Returns: N/A
 * Description: takes a file, check to see if there is room for it, if it is to big
 *              and some othere conditionals then reads it on block by block adding the
 *              block index to the inode
*/
void put(char * filename) // modified code from the main.c that was given via blackboard
{
  
  int    status;                   // Hold the status of all return values.
  struct stat buf;                 // stat struct to hold the returns from the stat call

  status =  stat( filename, &buf ); 

  if( status != -1 )
  {

    int copy_size   = buf . st_size;
    int inode_index = findFreeInode();
    int directory_index = findFreeDirectoryEntry();

  
    if(copy_size > MAX_FILE_SIZE)
    {
      printf("put error:: File is to large.\n");
      return;
    }
    if(copy_size > df())
    {
      printf("put error:: Remaining space is insufficient to store file.\n");
      return;
    }
    if(directory_index == -1)
    {
      printf("put error:: No directory entrys remaining.\n");
      return;
    }
    if(inode_index == -1)
    {
      printf("put error:: No inodes remaining.\n");
      return;
    }
    FILE *ifp = fopen ( filename, "r" );
    if(ifp == NULL)
    {
      printf("put error: Could not open %s\n",filename);
      return;
    }
    int k;
    directory_ptr[directory_index].name= malloc(strlen(filename) + 1);
    strcpy(directory_ptr[directory_index].name, filename);
    directory_ptr[directory_index].valid = 1;
    directory_ptr[directory_index].hasBeenUsed = 1;
    directory_ptr[directory_index].inode_idx = inode_index;
    time(&inode_array_ptr[inode_index]->data);
    inode_array_ptr[inode_index]->valid = 1;
    inode_array_ptr[inode_index]->file_size = copy_size;
    for(k = 0; k < MAX_BLOCKS_PER_FILE; k++) 
    { 
      used_blocks[inode_array_ptr[inode_index]->blocks[k]] = 0;
      inode_array_ptr[inode_index]->blocks[k] = 0;
    }
    //printf("%d %s %s\n",copy_size,ctime(&inode_array_ptr[inode_index]->data),filename);
    int offset = 0;              
    int block_index;
    int block_count = 0;
    while( copy_size > 0 )
    {
      block_index = findDataBlock();
      inode_array_ptr[inode_index]->blocks[block_count] = block_index;
      used_blocks[block_index] = 1;
      fseek( ifp, offset, SEEK_SET );
      int bytes  = fread( data_blocks[block_index], BLOCK_SIZE, 1, ifp );
      if( bytes == 0 && !feof( ifp ) )
      {
        printf("An error occured reading from the input file.\n");
        return;
      }
      clearerr( ifp );// Clear the EOF file flag.
      copy_size -= BLOCK_SIZE;     
      offset    += BLOCK_SIZE;
      block_count ++;
    }
    fclose( ifp );
  }
  else
  {
    printf("put error: File not found. %s\n", filename );
    return;
  }
}

/*
 * Function: get
 * Parameter(s): a string containing the filename of a file
 * Returns: N/A
 * Description: open up the file with name == filename (or creates it if there is none) and
 *              writes the content of the virtual save to it.
*/
void get(char * filename)
{
    int dir_idx = findDirIndex(filename);
    if(dir_idx == -1)
    {
      printf("get Error: File %s not in system.\n",filename);
      return;
    }
    FILE *ofp;
    ofp = fopen(filename, "w");
    if( ofp == NULL )
    {
      printf("get Error: Could not open output file: %s\n", filename );
      return;
    }
    int inode_index = directory_ptr[dir_idx].inode_idx;
    int block_index;
    int copy_size   = inode_array_ptr[inode_index]->file_size;
    int offset      = 0;
    int block_count = 0;
    //printf("Writing %d bytes to %s\n", (int) buf . st_size, filename );
    while( copy_size > 0 )
    { 
      int num_bytes; 
      block_index = inode_array_ptr[inode_index]->blocks[block_count];
      if( copy_size < BLOCK_SIZE )
      {
        num_bytes = copy_size;
      }
      else 
      {
        num_bytes = BLOCK_SIZE;
      }
      fwrite( data_blocks[block_index], num_bytes, 1, ofp ); 
      copy_size -= BLOCK_SIZE;
      offset    += BLOCK_SIZE;
      block_count ++;
      fseek( ofp, offset, SEEK_SET );
    }

    // Close the output file, we're done. 
    fclose( ofp );
}

/*
 * Function: findDirIndex
 * Parameter(s): a string containing a filename
 * Returns: the int of the directory that contains the file of filename.
 * Description:
*/
int findDirIndex (char * filename)
{
  int i;
  int index = -1;
  for(i = 0; i < NUM_FILES; i++)
  {
    if(directory_ptr[i].valid != 0)
    {
      if(strcmp(filename,directory_ptr[i].name) == 0)
      {
        index = i;
        break;
      }
    }
  }
  return index;
}

/*
 * Function: get_new
 * Parameter(s): a string of the name of a file in the filesystem. 
 *               a string of the name of the file to write to.
 * Returns: N/A
 * Description: find the readFile in the filesystem. if it exists then,
 *              block by block it is written to the write file. 
*/
void get_new(char * readfile, char * writefile)
{
    int dir_idx = findDirIndex(readfile);
    if(dir_idx == -1)
    {
      printf("get Error: File %s not in system.\n",readfile);
      return;
    }
    FILE *ofp;
    ofp = fopen(writefile, "w");
    if( ofp == NULL )
    {
      printf("get Error: Could not open output file: %s\n", writefile );
      return;
    }
    int inode_index = directory_ptr[dir_idx].inode_idx;
    int block_index;
    int copy_size   = inode_array_ptr[inode_index]->file_size;
    int offset      = 0;
    int block_count = 0;
    //printf("Writing %d bytes to %s\n", (int) buf . st_size, filename );
    while( copy_size > 0 )
    { 
      int num_bytes; 
      block_index = inode_array_ptr[inode_index]->blocks[block_count];
      if( copy_size < BLOCK_SIZE )
      {
        num_bytes = copy_size;
      }
      else 
      {
        num_bytes = BLOCK_SIZE;
      }
      fwrite( data_blocks[block_index], num_bytes, 1, ofp ); 
      copy_size -= BLOCK_SIZE;
      offset    += BLOCK_SIZE;
      block_count ++;
      fseek( ofp, offset, SEEK_SET );
    }

    // Close the output file, we're done. 
    fclose( ofp );
}

/*
 * Function: del
 * Parameter(s):a stirng containing the filename of the file you want to delete from the filesystem
 * Returns: N/A
 * Description: finds the file then sets the directory and inode valid int to 0 , showing they are ready for use.
*/
void del(char * filename)
{
  int i,k;
  int inode_index;
  int replace_blocks[MAX_BLOCKS_PER_FILE];
  for( i = 0; i < NUM_FILES; i++ )
  {
    if(directory_ptr[i].valid != 0)
    {
      if(strcmp(filename,directory_ptr[i].name) == 0)
      {
        inode_index = directory_ptr[i].inode_idx;
        directory_ptr[i].valid = 0;
        //free(directory_ptr[i].name);
        inode_array_ptr[inode_index]->valid = 0;
        /*for(k = 0; k < MAX_BLOCKS_PER_FILE; k++) 
        { 
          used_blocks[inode_array_ptr[inode_index]->blocks[k]] = 0;
          inode_array_ptr[inode_index]->blocks[k] = 0;
        }*/
        return;
      }
    }
    
  }
  printf("del error: File not found.\n");
  return;
}

/*
 * Function: undelete
 * Parameter(s): a stirng containing the filename of the file you want to undelete.
 * Returns: N/A
 * Description:finds the file out of directories that have been used but are currenty free
 *              then sets the inode and directoy valid to 0.
*/
void undelete(char * filename)
{
  //find file with dir_ptr name = name
  //get info from inode and set valid.
  // requires changing del function to no 
  //let there be memleaks.
  int i;
  int inode_index;
  for( i = 0; i < NUM_FILES; i++ )
  {
    if(directory_ptr[i].valid == 0  && directory_ptr[i].hasBeenUsed == 1)
    {
      if(strcmp(filename,directory_ptr[i].name) == 0)
      {
        inode_index = directory_ptr[i].inode_idx;
        directory_ptr[i].valid = 1;
        //free(directory_ptr[i].name);
        inode_array_ptr[inode_index]->valid = 1;
        return;
      }
    }
    
  }
  printf("undelete error: File not found.\n");
  return;
}

