/*****************************************************************************
 @author Sharma Chakravarthy, Soumyava Das
 LANGUAGE   : Java version 6
 PLATFORM   : PC
 Compiler   : javac
 
 CONCEPTS   : classes and methods
 PURPOSE    : defines an interface
******************************************************************************/

public interface Proj3Interface {
	public double computeSalary(int salaryParameter); //this cannot be static
}
